package clase02;

public class Clase02 {

    public static void main(String[] args) {
        
        System.out.println("Clase 03 - Día Nublado");
        
        int nro1=5;
        int nro2=7;
        System.out.println(nro1);
        System.out.println(nro2);
        
        //operadores de asignación  =
        nro1 = nro2;
        // <---
        System.out.println(nro1);
        System.out.println(nro2);
        
        //operadores aritmeticos e incrementales
        
        // sumar 1 a la variable nro1       ++
        nro1++;             //nro1=nro1+1;
        System.out.println(nro1);
        
        // restar 1 a la variable nro1      --
        nro1--;             //nro1=nro1-1;
        System.out.println(nro1);
        
        // sumar 5 a la variable nro1       +=
        nro1+=5;            //nro1=nro1+5;
        System.out.println(nro1);
        
        // restar 5 a la variable nro1      -=
        nro1-=5;            //nro1=nro1-5;
        System.out.println(nro1);
        
        // multiplicar * 5 la variable      *=5
        nro1*=5;            //nro1=nro1*5;
        System.out.println(nro1);
        
        // dividir la variable /5           /=
        nro1/=5;            //nro1=nro1/5;
        System.out.println(nro1);
        
        // precedencia y procedencia de operadores unarios  ++ --
        System.out.println(nro1++);         //7   
        System.out.println(nro1);           //8
        System.out.println(++nro1);         //9
        
        //constantes    final
        //final double PI=3.14;
        final double PI=Math.PI;
        //PI++;
        System.out.println(PI);
        
        
        //Ejercicio 1 - Asignación básica
        //Analice el código a continuación y complete la tabla correspondiente. 
        //Luego realice la codificación
        //para confirmar que ha completado la tabla correctamente.
        
        System.out.println("A");
        int x = 10;                     //10
        int y = 20;                     //20
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("B");
        x = x + 5;                      //15
        y = y + 10;                     //30
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("C");
        x = x - 5;                      //10
        y = y - 10;                     //20
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("D");
        x = x * 3;                      //30
        y = y * 5;                      //100
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x = x / 2;                      //15
        y = y / 4;                      //25
        System.out.println(x);
        System.out.println(y);
        
        /*
        Tabla para completar:

                x           y
        A       10          20
        B       15          30
        C       10          20
        D       30          100
        E.      15          25
        
        */
       
        //Ejercicio 2 - Asignación compacta
        //Analice el código a continuación y complete la tabla correspondiente. 
        //Luego realice la codificación
        //para confirmar que ha completado la tabla correctamente.
        
        System.out.println("A");
        x = 10;
        y = 20;
        System.out.println(x);              //10
        System.out.println(y);              //20
        
        System.out.println("B");
        x += 5;                             
        y -= 15;                            
        System.out.println(x);              //15
        System.out.println(y);              //5
        
        System.out.println("C");
        x++;
        y--;
        System.out.println(x);              //16
        System.out.println(y);              //4
        
        System.out.println("D");
        x *= 4;                             //64
        y *= -3;                            //-12
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("E");
        x /= 2;
        y /= 4;
        System.out.println(x);              //32
        System.out.println(y);              //-3
        
        /*
        Tabla para completar:

                x           y
        A       10          20  
        B       15          5
        C       16          4
        D       64          -12
        E       32          -3
        
        */

      
       //Ejercicio 3 - Operadores aritméticos
        System.out.println("A");
        x = 10;
        y = 20;
        System.out.println(x);          //10
        System.out.println(y);          //20
        
        System.out.println("B");
        x = x + y;                      //30
        y = y + x;                      //50
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("C");
        x= x - y;                       //-20
        y= y - x;                       //70
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("D");
        x=x * y;                        //-1400
        y=x * x;                        //1960000
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("E");
        x= y / x;                       
        y= x / y;
        System.out.println(x);          //-1400            
        System.out.println(y);          //0

        /*
        Tabla para completar:

                x           y
        A       10          20
        B       30          50 
        C       -20         70  
        D       -1400       1960000
        E       -1400       0
        
        */
        
        //Ejercicio 4- Operadores aritméticos con asignación compacta
        
        System.out.println("A");
        x = 5;
        y = 10;
        System.out.println(x);          // 5
        System.out.println(y);          // 10
        
        System.out.println("B");
        x += y;                         // 15
        y += x;                         // 25
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("C");
        x -= y;                         // -10
        y -= x;                         // 35
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("D");
        x *= y;                         // -350
        y *= x;                         // -12250
        System.out.println(x);
        System.out.println(y);
        
        System.out.println("E");
        x /= y;                         // 0
        y /= y;                         // 1
        System.out.println(x);
        System.out.println(y);
       
        /*
        Tabla para completar:

                x           y
        A       5           10
        B       15          25   
        C       -10         35 
        D       -350        -12250
        E       0           1
        
        */
        
        //Ejercicio 5- Operadores Aritméticos con asignación múltiple (suma y resta)
        System.out.println("A");
        x = 5;
        y = 10;
        int suma = 0;
        int resta = 0;
        System.out.println(x);          //5
        System.out.println(y);          //10
        System.out.println(suma);       //0
        System.out.println(resta);      //0
        
        System.out.println("B");
        suma = x + y;                   //15
        resta = x - y;                  //-5
        System.out.println(x);          //5
        System.out.println(y);          //10
        System.out.println(suma);       
        System.out.println(resta);      
        
        System.out.println("C");
        suma = x + x;                   //10
        resta = y - y;                  //0
        System.out.println(x);          //5
        System.out.println(y);          //10
        System.out.println(suma);       
        System.out.println(resta); 
        
        System.out.println("D");        
        suma = x + y + x;               //20
        resta = x - x - 20;             //-20
        System.out.println(x);          //5
        System.out.println(y);          //10
        System.out.println(suma);       
        System.out.println(resta); 
        
        System.out.println("E");
        suma = y + x + x;               //20
        resta = -x - y -y;              //-25         
        System.out.println(x);
        System.out.println(y);
        System.out.println(suma);       
        System.out.println(resta); 
        
        /*
        Tabla para completar:

                x           y           suma        resta
        A       5           10          0           0
        B       5           10          15          -5  
        C       5           10          10          0
        D       5           10          20          -20
        E       5           10          20          -25
        
        */
        
        //Ejercicio 6- Operadores Aritméticos con asignación múltiple (producto y división)
        System.out.println("A");
        x = 5;
        y = 10;
        int multi = 1;
        int division = 1;
        System.out.println(x);
        System.out.println(y);
        System.out.println(multi);
        System.out.println(division);
        System.out.println("B");
        multi = x * y;
        division = x / y;
        System.out.println(multi);
        System.out.println(division);
        System.out.println("C");
        multi = x * x;
        division = y / y;
        System.out.println(multi);
        System.out.println(division);
        System.out.println("D");
        multi = x * y * x;
        division = y / x;
        System.out.println(multi);
        System.out.println(division);
        System.out.println("E");
        multi= x * (-y);
        division= y / (-x);
        System.out.println(multi);
        System.out.println(division);
        
        /*
        Tabla para completar:

                x           y           multi       division
        A       
        B       
        C       
        D       
        E       
        
        */

        //TODO Operador Resto
        //TODO Concatenación de String
        //TODO Ingreso de datos por consola
        //TODO Lógica booleana
        //TODO Terminar laboratorio del PDF
        
    }
    
}
