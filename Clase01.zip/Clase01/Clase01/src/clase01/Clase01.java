package clase01;

public class Clase01 {

    public static void main(String[] args) {
        
        //Escribir código aquí.
        
        //Linea de comentarios
        
        System.out.println("Hola Mundo!");      //imprime hola mundo!!

        // ; para finalizar la sentencia
        // Lenguaje es case sensitive
        
        //F6 para ejecutar el programa
        
        System.out.println("Hoy llueve!!");
        //sout      TAB     atajo de teclado para System.out.println("");
        
        System.out.print("1");      //print imprime en la misma linea
        System.out.print("2");
        System.out.print("3");
        System.out.println("4");
        System.out.println("Centro de Formación Profesional Nro 35");
        
        /*
            CONSOLA 
        
            Hola Mundo!
            Hoy llueve!!
            1234
            Centro de Formación Profesional Nro 35
        
        */
        
        
        //Variables en Java
        
        //Variables Enteras
        int a;                  //declaración de una variable
        a=2;                    //asignación de valor
        
        int b=4;                //declaración y asignación de valor a una variable
        
        int c=a+b;              //6
        
        int d=67, e=46, f=72, g=26;     //declaración y asignación multiple de variable
        
        //una variable solo puede ser declarada una vez.
        //una variable puede tener infinitas asignaciones.
        
        //int a=6;      //Error no se puede volver a declarar una variable
        a=6;
        a=4;
        a=89;
        a=8;
        
        //indentificados = nombre de variable
        //indentificadores validos letras numeros y simbolo _ $
        //no puede iniciar un identificador con numeros
        int nro1=6;
        //int 1nro=6;       //Error
        int $1nro=6;
        int _1nro=6;
        //int &1nro=6;      //Error
        
        System.out.println(a);          //8
        System.out.println("Variable a: "+a);
        System.out.println("a+b="+a+b);         //a+b=84        //CUIDADO
        System.out.println("a+b="+(a+b));       //a+b=12
        
        
        //Tipo de datos String
        String p="perro";
        String l="ladra";
        
        System.out.println(p+l);                //perroladra
        System.out.println(p+" "+l);            //perro ladra
        System.out.println(p+" que "+l);        //perro que ladra
        
        //Tipo de datos char
        char ch=65;                 //A
        System.out.println(ch);
        
        ch+=32;         //sumando 32 a la variable          //a
        System.out.println(ch);
        
        ch='t';
        System.out.println(ch);
                
        ch='ñ';
        System.out.println(ch);
        
        //Tipo de datos boolean
        boolean bo=true;
        System.out.println(bo);
        bo=false;
        System.out.println(bo);
        
        //Tipo de datos float 32 bits
        float fl=8.25f;
        System.out.println(fl);
        
        
        //Tipo de datos double 64 bits
        double dl=8.25;
        System.out.println(dl);
        
        fl=10;
        dl=10;
        
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        fl=100;
        dl=100;
        
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        fl=1000;
        dl=1000;
        
        System.out.println(fl/3);
        System.out.println(dl/3);
        
        //TODO operadores de asignación
        //TODO operadores aritmeticos e incrementales
        //TODO constantes
        
    }
    
}
