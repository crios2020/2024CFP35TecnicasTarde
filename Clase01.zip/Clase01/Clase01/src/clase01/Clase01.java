package clase01;

public class Clase01 {

    public static void main(String[] args) {
        
        //Escribir código aquí.
        
        //Linea de comentarios
        
        System.out.println("Hola Mundo!");      //imprime hola mundo!!

        // ; para finalizar la sentencia
        // Lenguaje es case sensitive
        
        /*
            
        
        */
        
        
        
    }
    
}
